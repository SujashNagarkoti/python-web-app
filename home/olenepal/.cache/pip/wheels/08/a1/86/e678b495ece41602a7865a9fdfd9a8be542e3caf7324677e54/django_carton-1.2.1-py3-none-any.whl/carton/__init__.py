"""django-carton is a simple and lightweight application for shopping carts and wish lists."""

__version__ = '1.2.1'
